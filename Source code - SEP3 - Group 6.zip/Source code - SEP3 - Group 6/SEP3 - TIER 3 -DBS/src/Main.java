import Model.Model;
import Model.ModelManager;

public class Main
{
    public static void main(String[] args)
    {
        Model model = new ModelManager();

    }

}
