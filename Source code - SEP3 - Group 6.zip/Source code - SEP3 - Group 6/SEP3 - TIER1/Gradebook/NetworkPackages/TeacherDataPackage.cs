using WebApplication.Models;

namespace WebApplication.NetworkPackages
{
    public class TeacherDataPackage : NetworkPackage
    {
        public Teacher data { get; set; }
    }
}