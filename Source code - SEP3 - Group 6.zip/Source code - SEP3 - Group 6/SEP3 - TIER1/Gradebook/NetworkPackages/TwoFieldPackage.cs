namespace WebApplication.NetworkPackages
{
    public class TwoFieldPackage : NetworkPackage
    {
        public string firstField { get; set; }
        public string secondField { get; set; }

       
    }
}