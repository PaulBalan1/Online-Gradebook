package com.example.model;

public interface Model
{
}
