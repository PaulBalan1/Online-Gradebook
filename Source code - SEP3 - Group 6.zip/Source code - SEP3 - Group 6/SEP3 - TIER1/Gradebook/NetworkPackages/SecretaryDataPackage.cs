
using WebApplication.Models;

namespace WebApplication.NetworkPackages
{
    public class SecretaryDataPackage : NetworkPackage
    {
        public Secretary data { get; set; }
    }
}