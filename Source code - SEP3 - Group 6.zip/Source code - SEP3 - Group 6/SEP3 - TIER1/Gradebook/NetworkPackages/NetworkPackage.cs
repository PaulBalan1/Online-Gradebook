namespace WebApplication.NetworkPackages
{
    public class NetworkPackage
    {
        public string type { get; set; }
        public long id { get; set; }
    }
}