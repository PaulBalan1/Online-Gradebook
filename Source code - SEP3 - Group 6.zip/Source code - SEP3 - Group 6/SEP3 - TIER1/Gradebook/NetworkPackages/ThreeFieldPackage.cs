namespace WebApplication.NetworkPackages
{
    public class ThreeFieldPackage : NetworkPackage
    {
        public string firstField { get; set; }
        public string secondField { get; set; }
        public string thirdField { get; set; }
    }
}