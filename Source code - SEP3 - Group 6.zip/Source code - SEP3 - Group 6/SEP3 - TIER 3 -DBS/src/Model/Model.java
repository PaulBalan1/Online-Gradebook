package Model;

public interface Model
{
}
